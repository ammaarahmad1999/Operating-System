Name: AMMAAR AHMAD
Roll: 1801CS08
Assignment 8

1. Filename: Q1.c
Commands:
a. gcc Q1.c -o Q1
b. ./Q1
Output:
lock acquired by pthread1
pthread1 is accessing function f()
pthread2 cannot access function f() as lock acquired by pthread1
lock released by pthread1
lock acquired by pthread2
pthread2 is accessing function f()
lock released by pthread2


2. Filename: Q2.c
Commands:
a. gcc Q2.c -o Q2
b. ./Q2
Output:
Prime sum till 10000: 5736396


3. Filename: Q3.c
Commands:
a. gcc Q3.c -o Q3
b. ./Q3


