Name: Ammaar Ahmad
Roll: 1801cs08
Sub: OS Lab Assignment 1
Date: 12/01/2021


Ques 1: (file name: example1.bash)

execution commands:
1) chmod 777 example1.bash
2) ./example1.sh <any_number>


Ques 2: (file name: example2.sh)

execution commands:
1) chmod 777 example2.bash
2) ./example2.sh <first_number> <second_number>


Ques 3: (file name: example3.sh)

execution commands:
1) chmod 777 example3.bash
2) ./example3.bash <file_name> <number_to_compare>


Ques 4: (file name: example4.bash)

execution commands:
1) chmod 777 example4.bash
2) ./example4.bash <directory_path> <filename>_pattern <new_filename>
