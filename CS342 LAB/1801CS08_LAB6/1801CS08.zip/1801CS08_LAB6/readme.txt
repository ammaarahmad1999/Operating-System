Name: AMMAAR AHMAD
Roll: 1801CS08
Assignment 6

Question 1:

Commands:
1. gcc Q1.c -o Q1
2. ./Q1

Job execution using First Come First Serve(FCFS)

Input:
3
0 5
1 7
3 4

Output:
4.33 9.67
P1 P2 P3 



Question 2:

Commands:
1. gcc Q2.c -o Q2
2. ./Q2

Job execution using Shortest Job First(SJF)

Input:
3
0 5
1 7
3 4

Output:
3.33 8.67
P1 P3 P2 



Question 3:

Commands:
1. gcc Q3.c -o Q3
2. ./Q3

Job execution using Shortest Remaining Time First(SRTF)

Input:
3
0 5
1 7
3 4

Output:
3.33 8.67
P1 P3 P2 



Question 4:

Commands:

1. gcc Q4.c -o Q4
2. ./Q4 

Job execution using Highest Remaining Time First(HRTF)

Input:
3
0 5
1 7
3 4

Output:
8.33 13.67
P1 P2 P3 

