Name: AMMAAR AHMAD
Roll: 1801CS08
Assignment 7

Question 1:

Commands:
1. gcc Q1.c -o Q1
2. ./Q1

Job execution using Round Robin Scheduling Algorithm

Input:
6 2
0 4
1 5
2 2
3 1
4 6
6 3

Output:
Avg_WT = 7.33 Avg_TAT = 10.83
P3 P1 P4 P2 P6 P5 



Question 2:

Commands:
1. gcc Q2.c -o Q2
2. ./Q2

Job execution using Priority Scheduling (Non-Preemptive) Algorithm

Input:
4
0 10 5
1 6 4
3 2 2
5 4 0

Output:
Avg_WT = 7.75 Avg_TAT = 13.25
P1 P4 P3 P2 



Question 3:

Commands:
1. gcc Q3.c -o Q3
2. ./Q3

Job execution using Multilevel queue scheduling Algorithm (2 Queue: System and User Process) Both queue using round robin scheduling Algorithm 

Input:
5 2
0 10 2
3 7 1
4 6 2
12 5 1
18 8 1

Output:
Avg_WT = 10.40 Avg_TAT = 17.60
P2 P4 P5 P3 P1 




